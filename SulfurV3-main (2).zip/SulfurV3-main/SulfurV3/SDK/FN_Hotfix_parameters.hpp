#pragma once

// Fortnite (11.00) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Hotfix.OnlineHotfixManager.StartHotfixProcess
struct UOnlineHotfixManager_StartHotfixProcess_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
